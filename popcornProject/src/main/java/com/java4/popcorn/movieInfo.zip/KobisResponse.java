package com.java4.popcorn.movieInfo;

import lombok.Data;

@Data
public class KobisResponse {
    MovieListResult movieListResult;
}
