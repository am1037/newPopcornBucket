package com.java4.popcorn.movieInfo.kmdb;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.HttpURLConnection;
import java.net.URL;

public class KmdbAPI {
    String key = "&ServiceKey="+System.getenv("key4kmdb");
    String str = "http://api.koreafilm.or.kr/openapi-data2/wisenut/search_api/search_json2.jsp?collection=kmdb_new2&detail=N&listCount=100";
    public KmdbMovieSimpleInfoResponse getMovieInfo(int startCount){
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(str+key+"&startCount="+startCount).openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            ObjectMapper om = new ObjectMapper();
            return om.readValue(connection.getInputStream(), KmdbMovieSimpleInfoResponse.class);
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
//        KmdbAPI kmdbAPI = new KmdbAPI();
//        int i = 10;
//
//        KmdbMovieSimpleInfoResponse kmdbMovieSimpleInfoResponse = kmdbAPI.getMovieInfo(i);
//        kmdbMovieSimpleInfoResponse.printAsJson(""+i+".json");
        System.out.println(KmdbMovieSimpleInfoResponse.readFromJson("10.json").getData().get(0).getResult());

    }
}
